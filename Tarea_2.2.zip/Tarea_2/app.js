/**
 * TAREA 2 - Geoweb
 * Lógica de validación y análisis para el Visor TEMPO
 */

// =========================================================================
// A. Estructura condicional múltiple
// =========================================================================


function evaluarCalidadAireNO2(medicion) {
    let diagnostico = "";

    if (medicion >= 150) {
        diagnostico = "Calidad del aire: Crítica";
    } else if (medicion >= 100) {
        diagnostico = "Calidad del aire: Regular";
    } else {
        diagnostico = "Calidad del aire: Buena";
    }
    
    return diagnostico; // Punto C (retornar valor)
}

// =========================================================================
// B. Al menos dos estructuras iterativas con operadores lógicos
// =========================================================================

/**
 * ESTRUCTURA ITERATIVA 1: Bucle 'for' con operador lógico '&&' (AND).
 * Propósito: Limpiar una matriz de datos eliminando valores erróneos del sensor.
 */
function filtrarMedicionesAnomalas(mediciones) {
    let medicionesValidas = [];

    for (let i = 0; i < mediciones.length; i++) {
        // Operador lógico &&: La lectura es válida solo si es mayor a 0 Y menor o igual a 500 ppb
        if (mediciones[i] > 0 && mediciones[i] <= 500) {
            medicionesValidas.push(mediciones[i]);  
        }
    }
    return medicionesValidas;
}


// =========================================================================
// C. Funciones con argumentos variables que retornen valores
// B. Estructura iterativa 2 con operadores lógicos
// =========================================================================

/**
 * ESTRUCTURA ITERATIVA 2: Bucle 'while' con operador lógico OR.
 * Función con ARGUMENTOS VARIABLES 
 * Propósito: Analizar una cantidad indefinida de lecturas satelitales buscando alertas.
 */
function analizarCalidadAire(...valoresSatelitales) {
    // Si no se envían argumentos, retornamos un mensaje por defecto
    if (valoresSatelitales.length === 0) {
        return "No hay datos satelitales para analizar.";
    }

    let i = 0;
    let alertaDetectada = false;

    // Iteramos mientras haya elementos Y no hayamos encontrado una alerta
    while (i < valoresSatelitales.length && alertaDetectada === false) {
        
        // Operador lógico ||: Se dispara alerta si el valor es negativo (error) O supera los 120 ppb (peligro)
        if (valoresSatelitales[i] < 0 || valoresSatelitales[i] > 120) {
            alertaDetectada = true;
        }
        i++;
    }

    if (alertaDetectada) {
        return "¡Alerta! Se detectaron valores críticos o erróneos en el muestreo satelital.";
    } else {
        return "Valores dentro del rango nominal permitido.";
    }
}




// Pruebas de ejecución (Mostrando los resultados en la página HTML)
// =========================================================================
//Con una variable de texto vacía se va guardando todo. 
// Usamos <br> para que el HTML haga saltos de línea
// =========================================================================
let textoResultados = "";

textoResultados += "<strong>--- Punto A y C: Condicional Múltiple ---</strong><br>";
textoResultados += "Lectura 160 ppb: " + evaluarCalidadAireNO2(160) + "<br>";
textoResultados += "Lectura 85 ppb: " + evaluarCalidadAireNO2(85) + "<br><br>";

let muestrasEstacion = [35.2, -5.0, 42.1, 800.5, 28.4]; 
textoResultados += "<strong>--- Punto B: Filtrado de Anomalías (for + &&) ---</strong><br>";
const filtradas = filtrarMedicionesAnomalas(muestrasEstacion);
textoResultados += "Muestras validadas: " + filtradas + "<br><br>";

textoResultados += "<strong>--- Punto B y C: Análisis Satelital (while + or) ---</strong><br>";
textoResultados += "Análisis zona Centro: " + analizarCalidadAire(35.0, 130.5, 40.0) + "<br><br>";

textoResultados += "<strong>--- Punto D: Sort de mediciones filtradas (array)---</strong><br>";
const sorteadas = filtradas.sort();
textoResultados += "Muestras filtradas y ordenadas: " + sorteadas + "<br><br>";

textoResultados += "<strong>--- Punto E: Strings---</strong><br>";
const encadenadas = [];
sorteadas.forEach(num => {encadenadas.push(" "  + num.toString() + " µg/m³");});
textoResultados += "Números a cadenas: " + encadenadas + "<br>";


// Se busca etiqueta por su ID y se integra el texto
document.getElementById("pantalla-resultados").innerHTML = textoResultados;


